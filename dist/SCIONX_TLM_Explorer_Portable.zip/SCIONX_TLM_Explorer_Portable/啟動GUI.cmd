@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0SCIONX_TLM_Explorer.exe"
